var express = require('express');
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');
var secret = 'nghiakhoi';
var crypto = require('crypto');
var app = express();

app.use(bodyParser.json());

var urlencodedParser = bodyParser.urlencoded({ extended: false });

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'testappbanhang'
});

function Casi(id,ten,hinh){
  this.id = id;
  this.ten = ten;
  this.hinh = hinh;
};

var mang = [];

connection.connect();

connection.query('SELECT * from casi', function (error, results, fields) {
  if (error) throw error;
  mang = results;
});


app.get('/', function(req, res){
	res.send(JSON.stringify(mang));
});

app.get('/trang/:page', function(req, res){
  var soItem1trang = 3;
  var page = req.params.page;
  var from = page * soItem1trang;
  var mangMoi = [];
  for (var i = from; i <= from+2; i++) {
    mangMoi.push(mang[i]);
  }
  res.send(JSON.stringify(mangMoi));
});

app.post('/cong', function(req, res){
  var json = req.body;
  var a = parseInt(json.numberOne);
  var b = parseInt(json.numberTwo);
  var c = a+b;
  var result='{"kq": "'+ c + '"}';

  res.send(result);
});

app.post('/dangky', function(req, res){
  var json = req.body;
  var hoten = (json.hoten);
  var username = (json.username);
  var password = (json.password);
  console.log(json);
  connection.query("insert into nhanvien set ?", {id:null,hoten:hoten,username:username,password:password}, function (error, results, fields) {
    if (error) throw error;
    console.log(results.insertId);
    res.send({kq: results.insertId});
  });
});
var taotoken="";
app.post('/taotoken', function(req, res){
  var un = req.body.USERNAME;
  var pa = crypto.createHash('md5').update(req.body.PASSWORD).digest("hex");
  connection.query("select * from users where username=? and password=?", [un,pa], function (error, results, fields) {
    if (error){
      throw error;
    } else{
      if(results.length==1){
        var token = jwt.sign({
          id:results[0]['id'],
          username:results[0]['username'],
          hoten:results[0]['hoten'],
          email:results[0]['email'],
        }, secret,{expiresIn:3000});
        taotoken= token;
        res.send({token: token});
      }else{
        res.send({token:"Banh xác rồi"});
      }
    }
  });
  
  //res.send(token);
});

app.get('/checktoken', function(req, res){
  var token = taotoken;
  if(token){
    jwt.verify(token, secret, function(err, decoded){
      if(err){
        return res.json({
          message1: "chưa xác định"
        });
      } else{
        //req.decoded = decoded;
        res.json({id:decoded.id,hoten:decoded.hoten,email:decoded.email});
      }
    });
  }else{
    res.json({
      message2: "chưa xác định"
    });
  }
});

app.listen(3000, function(){
	console.log('App da chay ok');
});