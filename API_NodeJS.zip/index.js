var express = require('express');
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');
var secret = 'nghiakhoi';
var crypto = require('crypto');
var app = express();

app.use(bodyParser.json());
app.use(express.static("public"));

var urlencodedParser = bodyParser.urlencoded({ extended: false });

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'myshop',
  dateStrings: 'true'
});

connection.connect();

app.get('/', function(req, res){
  connection.query('SELECT p.id,p.name as name ,p.id_type as idType, t.name as nameType, p.price, p.color, p.material, p.description, GROUP_CONCAT(i.link) AS images FROM product p LEFT JOIN images i ON p.id = i.id_product inner join product_type t ON t.id = p.id_type where p.new = 1 group by p.id LIMIT 0,6', function (error, results, fields) {
    if (error){
      throw error;
    } else{
      if(results.length>0){
        var product = results;
        for(var i =0;i<product.length;i++){
          var assignees = product[i]['images'].split(",");
          product[i]['images']=assignees;
        }
        connection.query('Select * from product_type', function (error, results, fields) {
          if (error){
            throw error;
          } else{
            if(results.length>0){
              var type = results;
              res.json({type:type,product:product});
            }else{
              res.json({token:"Banh xác rồi"});
            }
          }
        });
      }
    }
  });
});

app.post('/register', function(req, res){
  var json = req.body;
  var email = (json.email);
  var name = (json.name);
  var password = crypto.createHash('md5').update(json.password.toString()).digest("hex");
  if(email!='' && name!='' && password!=''){
    connection.query('INSERT INTO users set ?', {id:null,email:email,password:password,name:name}, function (error, results, fields) {
      if (error){
        res.json({kq:'KHONG_THANH_CONG', error:error.message});
      } else{
        if(results){
          var type = results.insertId;
          res.json({kq:'THANH_CONG', id: type});
        }else{
          res.json({kq:'KHONG_THANH_CONG'});
        }
      }
    });
  } else{
    res.json({kq:'KHONG_THANH_CONG'});
  }
});

app.post('/login', function(req, res){
  var json = req.body;
  var email = (json.email);
  var password = crypto.createHash('md5').update(json.password.toString()).digest("hex");

  connection.query('SELECT u.email, u.name, u.address, u.phone FROM users u where email = ? and password = ?', [email,password], function (error, results, fields) {
    if (error){
      res.json({kq:'KHONG_THANH_CONG', error:error.message});
    } else{
      if(results.length==1){
        var token = jwt.sign({
          iat: (new Date()).getTime(),
          expire:((new Date()).getTime() + 172800000), //2 days
          email:email
        }, secret,{expiresIn:172800000});
        var array={token:token, user:results[0]};
        res.json(array);
      }else{
        res.json({kq:'SAI_THONG_TIN_DANG_NHAP'});
      }
    }
  });
});

app.post('/checklogin', function(req, res){
  var json = req.body;
  var token = (json.token);
  try{
    if(token){
      jwt.verify(token, secret, function(err, decoded){
        if(err){
          return res.json({
            kq: "TOKEN_KHONG_HOP_LE"
          });
        } else{
          if(decoded.expire < (new Date()).getTime()){
            return res.json({
              kq: "TOKEN_HET_HAN"
            });
          }else{
            var email = decoded.email;
            connection.query('SELECT * FROM users where email = ?', [email], function (error, results, fields) {
              if(results.length==1){
                var newtoken = jwt.sign({
                  iat: (new Date()).getTime(),
                  expire:((new Date()).getTime() + 172800000), //2 days
                  email:email
                }, secret,{expiresIn:172800000});
                var array={token:newtoken, user:results[0]};
                res.json(array);
              }
            });
          }
        }
      });
    }else{
      res.json({
        message2: "TOKEN_KHONG_HOP_LE"
      });
    }
  }catch(err){
    return res.json({
      kq: "TOKEN_KHONG_HOP_LE"
    });
  }
  
});

app.post('/refreshtoken', function(req, res){
  var json = req.body;
  var token = (json.token);
  try{
    jwt.verify(token, secret, function(err, decoded){
      if(err){
        return res.send("TOKEN_KHONG_HOP_LE");
      } else{
        if(decoded.expire < (new Date()).getTime()){
          return res.send("TOKEN_HET_HAN");
        }else{
          var email = decoded.email;
          var newtoken = jwt.sign({
            iat: (new Date()).getTime(),
              expire:((new Date()).getTime() + 172800000), //2 days
              email:email
            }, secret,{expiresIn:172800000});
          res.send(newtoken);
        }
      }
    });
  }catch(err){
    return res.send("TOKEN_KHONG_HOP_LE");
  }
});

app.post('/changeinfo', function(req, res){
  var json = req.body;
  var token = (json.token);
  var name = (json.name);
  var phone = (json.phone);
  var address = (json.address);
  try{
    if(token){
      jwt.verify(token, secret, function(err, decoded){
        if(err){
          return res.json({
            kq: "TOKEN_KHONG_HOP_LE"
          });
        } else{
          if(decoded.expire < (new Date()).getTime()){
            return res.json({
              kq: "TOKEN_HET_HAN"
            });
          }else{
            var email = decoded.email;
            connection.query('UPDATE users SET name=?, phone=?, address=? WHERE email =?', [name,phone,address,email], function (error, results, fields) {
              if(results){
                connection.query('SELECT u.email, u.name, u.address, u.phone FROM users u where email = ?', [email], function (error, results, fields) {
                  if(results.length==1){
                    console.log(results[0]);
                    var array=results[0];
                    res.json(array);
                  }else{
                    return res.json({
                      kq: "LOI_TRUY_VAN"
                    })
                  }
                })}
                else{
                  return res.json({
                    kq: "LOI_TRUY_VAN"
                  });
                }
              });
          }
        }
      });
    }else{
      res.json({
        message2: "TOKEN_KHONG_HOP_LE"
      });
    }
  }catch(err){
    return res.json({
      kq: "TOKEN_KHONG_HOP_LE"
    });
  }
});

app.get('/getproductbytype/:id_type/:page', function(req, res){
  var id_type = req.params.id_type;
  var limit = 3;
  var page = parseInt(req.params.page?req.params.page:1);
  var offset = (page - 1) * limit;

  connection.query('SELECT p.*, t.name as nameType, GROUP_CONCAT(i.link) AS images FROM product p inner join product_type t ON t.id = p.id_type INNER JOIN images i ON i.id_product = p.id WHERE id_type = ? group by p.id LIMIT ?,? ', [id_type,offset,limit], function (error, results, fields) {
    if (error){
      throw error;
    } else{
      if(results.length>0){
        var product = results;
        for(var i =0;i<product.length;i++){
          var assignees = product[i]['images'].split(",");
          product[i]['images']=assignees;
        }
        res.json(product);
      } else{
        res.json({product:'không có sản phẩm nào'});
      }
    }
  });
});

app.get('/search/:key', function(req, res){
  if(req.params.key && req.params.key.length>2){
    var keyword = req.params.key;
    connection.query('SELECT p.*, GROUP_CONCAT(i.link) AS images FROM product p INNER JOIN images i ON p.id = i.id_product where name like ? group by p.id', ['%'+keyword+'%'], function (error, results, fields) {
      if (error){
        throw error;
      } else{
        if(results.length>0){
          var product = results;
          for(var i =0;i<product.length;i++){
            var assignees = product[i]['images'].split(",");
            product[i]['images']=assignees;
          }
          res.json(product);
        } else{
          res.json({product:'không có sản phẩm nào'});
        }
      }
    });
  }  
});

//get today
var gettoday = function(){
  var today = new Date();
  var dd = today.getDate();
  var mm = today.getMonth()+1;
  var yyyy = today.getFullYear();
  var hh = today.getHours();
  var min = today.getMinutes();
  var ss = today.getSeconds();

  if(dd<10) {
    dd='0'+dd
  } 

  if(mm<10) {
    mm='0'+mm
  } 
  return today = yyyy+'/'+mm+'/'+dd+' '+hh+':'+min+':'+ss;
}
//end get today

app.post('/cart', function(req, res){
  var json = req.body;
  var token = (json.token);
  var arrayDetail = (json.arrayDetail);
  try{
    if(token){
      jwt.verify(token, secret, function(err, decoded){
        if(err){
          return res.json({
            kq: "TOKEN_KHONG_HOP_LE"
          });
        } else{
          if(decoded.expire < (new Date()).getTime()){
            return res.json({
              kq: "TOKEN_HET_HAN"
            });
          }else{
            var email = decoded.email;
            connection.query('SELECT * FROM users where email = ?', [email], function (error, results, fields) {
              if(results.length>0){
                var id_user=results[0].id;
                var arr = arrayDetail.map( function(el) { return el.id; });
                var tongtien=0;
                connection.query('select price from product where id IN ('+arr+')', function (error, results, fields) {
                  if(results){
                    results.forEach(function(i){
                      tongtien = tongtien + parseInt(i['price']);
                    });
                    var todate = gettoday();
                    connection.query('INSERT INTO bill set ?', {id_customer:id_user,date_order:todate,total:tongtien}, function (error, results, fields) {
                      if(results){
                        var id_bill=results.insertId;
                        connection.query('Select * FROM product where id IN ('+arr+')', function (error, results, fields) {
                          if (results) {
                            var soluong=0;
                            var dem=0;
                            var newbills = [];
                            results.forEach(function(i){
                              var price = i['price'];
                              arrayDetail.forEach( function(el) { 
                                if(el.id===i['id']){
                                  soluong=el['quantity'];
                                  newbills.push([id_bill,i['id'],soluong,price]);
                                }
                              });
                            });
                            connection.query('INSERT INTO bill_detail (id_bill,id_product,quantity,price) values ?', [newbills], function (error, results, fields) {
                              if(err) {
                                console.log(err);
                                return res.send("LOI_TRUY_VAN");
                              }else{
                                console.log(fields);
                                return res.send("THEM_THANH_CONG");
                              }
                            });
                          }
                        });
                      }
                    });
                  }
                });
              }
              else{
                return res.json({
                  kq: "LOI_TRUY_VAN"
                });
              }
            });
          }
        }
      });
    }else{
      res.json({
        message2: "TOKEN_KHONG_HOP_LE"
      });
    }
  }catch(err){
    return res.json({
      kq: "TOKEN_KHONG_HOP_LE"
    });
  }
});

app.post('/orderhistory', function(req, res){
  var json = req.body;
  var token = (json.token);
  try{
    jwt.verify(token, secret, function(err, decoded){
      if(err){
        return res.send("TOKEN_KHONG_HOP_LE");
      } else{
        if(decoded.expire < (new Date()).getTime()){
          return res.send("TOKEN_HET_HAN");
        }else{
          var email = decoded.email;
          connection.query('SELECT b.id, b.date_order, b.status, b.total FROM bill b INNER JOIN users u ON u.id=b.id_customer where u.email =?', [email], function (error, results, fields) {
            if (results) {
              return res.json(results);
            }
          });
        }
      }
    });
  }catch(err){
    return res.send("TOKEN_KHONG_HOP_LE");
  }
});

app.get('/getcollection/:page', function(req, res){
  var limit = 3;
  var page = parseInt(req.params.page?req.params.page:1);
  var offset = (page - 1) * limit<1?0:(page - 1) * limit;

  connection.query('SELECT p.*, GROUP_CONCAT(i.link) AS images FROM images i inner join product p ON i.id_product = p.id where inCollection=1  group by p.id  LIMIT ?,? ', [offset,limit], function (error, results, fields) {
    if (error){
      throw error;
    } else{
      if(results.length>0){
        var product = results;
        for(var i =0;i<product.length;i++){
          var assignees = product[i]['images'].split(",");
          product[i]['images']=assignees;
        }
        res.json(product);
      } else{
        res.json({product:'không có sản phẩm nào'});
      }
    }
  });
});

app.listen(3000, function(){
 console.log('App da chay ok');
});